import pandas as pd
import matplotlib.pyplot as plt


dados = {
    "N": [500, 1000, 2000, 4000, 8000, 16000],
    "Solução ingênua (s)": [
        0.0973, 0.4057, 1.5501, 6.3500, 25.3904, 101.8355
    ],
    "Tabela hash (s)": [
        0.0010, 0.0011, 0.0023, 0.0048, 0.0099, 0.0211
    ]
}

df = pd.DataFrame(dados)

print("\n" + "=" * 60)
print("        FLOCOS DE NEVE — TEMPOS DE EXECUÇÃO")
print("=" * 60)

print(
    f"{'N':>8}"
    f"{'Solução ingênua (s)':>24}"
    f"{'Tabela hash (s)':>20}"
)

print("-" * 60)

for _, linha in df.iterrows():
    print(
        f"{linha['N']:>8.0f}"
        f"{linha['Solução ingênua (s)']:>24.4f}"
        f"{linha['Tabela hash (s)']:>20.4f}"
    )

print("=" * 60)

plt.figure(figsize=(10, 6))

plt.plot(
    df["N"],
    df["Solução ingênua (s)"],
    marker="o",
    label="Solução ingênua"
)

plt.plot(
    df["N"],
    df["Tabela hash (s)"],
    marker="o",
    label="Tabela hash"
)

plt.xlabel("Quantidade de flocos (N)")
plt.ylabel("Tempo de execução (s)")
plt.title("Flocos de neve — comparação das soluções")

plt.xticks(df["N"])
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()

plt.savefig("tempos_execucao.png", dpi=300)
plt.show()