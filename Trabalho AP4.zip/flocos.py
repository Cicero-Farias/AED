"""
Problema dos Flocos de Neve — comparação de tempo de execução
================================================================

Um floco de neve é descrito por 6 inteiros, representando o comprimento
de cada uma das seus 6 pontas, na ordem em que aparecem ao redor do centro
(sentido horário ou anti-horário, mas o ponto de partida é arbitrário).

Dois flocos são "gêmeos" se um é uma rotação do outro. Por exemplo,
    [2, 3, 1, 4, 5, 6]  e  [1, 4, 5, 6, 2, 3]
são gêmeos (a segunda lista é a primeira "girada").

Dado um conjunto de N flocos, o objetivo é responder:
    existe algum par de flocos gêmeos?

Complete as funções abaixo. Depois use a função `benchmark` no final
do arquivo para comparar os tempos de execução das duas abordagens.
"""

import time
import itertools


def le_instancia(caminho):
    """Lê um arquivo no formato do problema e retorna uma lista de flocos.
    Cada floco é uma lista de 6 inteiros."""
    with open(caminho) as f:
        n = int(f.readline())
        flocos = []
        for _ in range(n):
            flocos.append(list(map(int, f.readline().split())))
    return flocos


def sao_gemeos(a, b):
    """Verifica se dois flocos são gêmeos.

    Gera as 6 rotações possíveis do floco `a` e verifica
    se alguma delas é igual ao floco `b`.

    Retorna True se os flocos forem gêmeos e False caso contrário.
    """
    for i in range(6):
        rotacao = a[i:] + a[:i]

        if rotacao == b:
            return True

    return False


def existe_par_gemeo_ingenuo(flocos):
    """Procura um par de flocos gêmeos usando a solução ingênua.

    Compara cada par de flocos da coleção, um a um, utilizando
    a função `sao_gemeos`.

    Retorna uma tupla (i, j) contendo os índices do primeiro
    par gêmeo encontrado ou None caso não exista nenhum par.
    """
    for i in range(len(flocos)):
        for j in range(i + 1, len(flocos)):
            if sao_gemeos(flocos[i], flocos[j]):
                return (i, j)

    return None


def chave_canonica(floco):
    """Calcula uma chave canônica para um floco.

    Gera as 6 rotações possíveis do floco e escolhe a menor
    em ordem lexicográfica. Flocos que são gêmeos possuem
    a mesma chave canônica.

    Retorna a menor rotação do floco como uma tupla.
    """
    rotacoes = []

    for i in range(6):
        rotacao = floco[i:] + floco[:i]
        rotacoes.append(tuple(rotacao))

    return min(rotacoes)


def existe_par_gemeo_hash(flocos):
    """Solução com tabela hash (dict/set nativos do Python).

    Percorre os flocos uma única vez, mantendo uma tabela hash das
    chaves canônicas já vistas. Retorna (i, j) do primeiro par gêmeo
    encontrado, ou None se não existir nenhum.
    """
    vistos = {}

    for i, floco in enumerate(flocos):
        chave = chave_canonica(floco)

        if chave in vistos:
            return (vistos[chave], i)

        vistos[chave] = i

    return None


# ---------------------------------------------------------------------
# Ferramentas de benchmark
# NÃO PRECISA MEXER AQUI
# ---------------------------------------------------------------------

def benchmark(caminho, algoritmo, repeticoes=3):
    flocos = le_instancia(caminho)
    tempos = []
    for _ in range(repeticoes):
        inicio = time.perf_counter()
        resultado = algoritmo(flocos)
        fim = time.perf_counter()
        tempos.append(fim - inicio)
    return min(tempos), resultado


if __name__ == "__main__":
    instancias = [
        #descomente conforme for testando N maiores
        #"instancias/floco_2000_gemeo_inicio.txt",
        #"instancias/floco_2000_gemeo_fim.txt",
        "instancias/floco_debug_12.txt",
        "instancias/floco_semgemeos_500.txt",
        "instancias/floco_semgemeos_1000.txt",
        "instancias/floco_semgemeos_2000.txt",
        "instancias/floco_semgemeos_4000.txt",
        "instancias/floco_semgemeos_8000.txt",
        "instancias/floco_semgemeos_16000.txt",
    ]

    print(f"{'instância':30s} {'N':>7s} {'ingênuo (s)':>14s} {'hash (s)':>12s}")
    for nome in instancias:
        flocos = le_instancia(nome)
        n = len(flocos)

        t_ingenuo, r1 = benchmark(nome, existe_par_gemeo_ingenuo)
        t_hash, r2 = benchmark(nome, existe_par_gemeo_hash)

        assert (r1 is None) == (r2 is None), "as duas soluções discordam!"

        print(f"{nome:30s} {n:7d} {t_ingenuo:14.4f} {t_hash:12.4f}")